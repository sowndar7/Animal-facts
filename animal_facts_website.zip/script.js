const facts = [
  {
    fact: "Elephants are the only animals that can't jump.",
    img: "https://upload.wikimedia.org/wikipedia/commons/3/37/African_Bush_Elephant.jpg"
  },
  {
    fact: "A group of flamingos is called a 'flamboyance'.",
    img: "https://upload.wikimedia.org/wikipedia/commons/4/4e/Flamingo_group.jpg"
  },
  {
    fact: "Octopuses have three hearts and blue blood.",
    img: "https://upload.wikimedia.org/wikipedia/commons/6/6e/Octopus2.jpg"
  },
  {
    fact: "Koalas sleep up to 22 hours a day!",
    img: "https://upload.wikimedia.org/wikipedia/commons/4/49/Koala_climbing_tree.jpg"
  }
];

function showRandomFact() {
  const random = facts[Math.floor(Math.random() * facts.length)];
  document.getElementById("animal-fact").textContent = random.fact;
  document.getElementById("animal-img").src = random.img;
}
